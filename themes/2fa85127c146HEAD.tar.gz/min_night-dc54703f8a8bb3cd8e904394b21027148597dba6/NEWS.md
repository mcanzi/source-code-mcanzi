# v0.0.4 2019-09-15
Support Talk/Coral with partial templates TY @mzch
Replace deprecated Hugo link variables with `.RelPermaLin` TY @mzch

# v0.0.3
Support FontAwesome5 thanks to @BPDranka
